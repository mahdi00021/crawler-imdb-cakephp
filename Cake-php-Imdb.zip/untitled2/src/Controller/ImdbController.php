<?php

namespace App\Controller;

use App\ImdbClasses\DataBaseHandler;
use App\ImdbClasses\ExtractorImdb;
use App\Repository\RepositoryImdb;


/**
 * Class ImdbController
 *
 * @author mahdi norouzi
 *
 * @package App\Controller

 */

class ImdbController extends AppController
{

    var $Repository;

    /**
     *@param $url
     *@return mixed
     */
    public function view($url)
    {

        $dataModel = new DataBaseHandler();
        $extract =  new ExtractorImdb();

        //Main method for set Data
        $extract-> setLoadDataByUrl($url);

        $titleId = $extract-> getTitleId();
        $title = $extract-> getTitle();
        $cast = $extract-> getCast();
        $mediaImages = $extract-> getImages();

        //insert in database
        $dataModel-> insertData($titleId, $title, $cast, $mediaImages);

        //or insert data by 'Repository Pattern'
        $this->Repository = new RepositoryImdb();
        $this->Repository->insertData($titleId, $title, $cast, $mediaImages);

        //return json output
        return $extract-> getMovieInfoByUrl($url);

    }

}