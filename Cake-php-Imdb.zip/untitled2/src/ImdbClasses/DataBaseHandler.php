<?php

namespace App\ImdbClasses;

use Cake\ORM\TableRegistry;

/**
 * Class DataBaseHandler
 * @package App\ImdbClasses
 */
class DataBaseHandler
{


    /**
     * @param $titleId
     * @param $title
     * @param $cast
     * @param $mediaImages
     * @return string
     */
    public function insertData($titleId,$title,$cast,$mediaImages)
    {
        if ($titleId && $title && $cast && $mediaImages !='') {

            $imdbItem = TableRegistry::get('Imdb');

            $query = $imdbItem->query();
            $query->insert(['titleId', 'title', 'cast', 'mediaImages'])
                ->values([
                    'titleId' => $titleId,
                    'title' => $title,
                    'cast' => $cast,
                    'mediaImages' => $mediaImages
                ])
                ->execute();

        } else {

            return 'Error in insert data';
        }
    }


}