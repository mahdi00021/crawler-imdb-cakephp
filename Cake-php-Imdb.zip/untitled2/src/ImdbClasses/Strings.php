<?php

namespace App\ImdbClasses;



/**
 * @author mahdi norouzi
 * This class is repository regex text
 * Class Strings
 * @package App\ImdbClasses
 */
class Strings
{

    public $regex;
    public $items;


    /**
     * function string() for return all regex text
     * @return $this
    */
    public function string()
    {

        $this->regex = (object)[

            'titleId'=> '/<link rel="canonical" href="https:\/\/www.imdb.com\/title\/(tt\d+)\/reference" \/>/ms',
            'title' => '/<title>(IMDb \- )*(.*?) \(.*?<\/title>/ms',
            'castAllKeyMatch' =>'/<a href="\/name\/(nm\d+).*?>(.*?)<\/a>/ms',
            'castMatch' => '/Cast.*?<\/h4>.*?<table.*?>(.*?)<\/table>/ms',
            'mediaImagesMatchAll' => '/<a.*?>(\d*)<\/a>/ms',
            'mediaImagesMatch' => '/<span class="page_list">(.*?)<\/span>/ms',
            'scanMediaMatchAll' => '/src="(.*?)"/msi',
            'scanMediaMatch' => '/<div class="media_index_thumb_list".*?>(.*?)<\/div>/msi',


        ];

        return $this;
    }



    /**
     * @return $this
     */
    public function texts()
    {

        $this->items = (object)[

             'request' => "Mozilla/" . rand(3, 5) . "." . rand(0, 3) . " (Windows NT " . rand(3, 5) . "." . rand(0, 2) . "; rv:2.0.1) Gecko/20100101 Firefox/" . rand(3, 5) . ".0.1",
             'url' => "https://www.imdb.com/title/",

        ];

        return $this;
    }
}

