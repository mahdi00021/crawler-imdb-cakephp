<?php

namespace App\ImdbClasses;

use App\ImdbClasses\Imdb;



/**
 * Get json of title , cast , images
 *
 * Set setters and getters extends Imdb
 *
 * @author mahdi norouzi
 * Class ExtractorImdb
 * @package App\ImdbClasses
 */

class ExtractorImdb extends Imdb
{



    /**
     * Main method for crawl content Get movie information by IMDb Id
     * @return mixed
     */
    public function getMovieInfoByUrl($Url)
    {
        if ($Url !='') {

            header('Content-type: application/json');
            return $this->jsonCrawlerMovieInfo($Url);
        } else {

            return 'Erorr in operation';

        }
    }


    /**
     * This method is for set Data by url content for setters and getters methods
     *
     * @param $imdbUrl
     *
     * @return string
     */
    public function setLoadDataByUrl($imdbUrl)
    {

        if ($imdbUrl !='') {

            $htmlContent = $this->getContentOfUrl("${imdbUrl}reference");
            $title_id = $this->getExtractTitleId($htmlContent);

            if (empty($title_id) || !preg_match("/tt\d+/i", $title_id)) {
                $response = "No Title found on IMDb!";
                return $response;
            }

            $title = $this->getExtractTitle($htmlContent);
            $cast = $this->getExtractCast($htmlContent);
            $MediaImages = $this->getExtractMediaImages($title_id);

            //set for setters and getters
            $this->set($title_id, $title, $cast, $MediaImages);

        } else {

            return 'Erorr in operation';

        }
    }



    /**
     * @param $imdbUrl
     * @return array|string json
     */
    public function jsonCrawlerMovieInfo($imdbUrl)
    {
        if ($imdbUrl != '') {

            $arr = array();
            $htmlContent = $this->getContentOfUrl("${imdbUrl}reference");
            $title_id = $this->getExtractTitleId($htmlContent);

            if (empty($title_id) || !preg_match("/tt\d+/i", $title_id)) {
                $arr['error'] = "No Title found on IMDb!";
                return $arr;
            }

            $title = $this->getExtractTitle($htmlContent);
            $cast = $this->getExtractCast($htmlContent);
            $MediaImages = $this->getExtractMediaImages($title_id);

            $this->set($title_id, $title, $cast, $MediaImages);

            $arr['title_id'] = $this->getTitleId();
            $arr['title'] = $this->getTitle();
            $arr['cast'] = $this->getCast();
            $arr['MediaImages'] = $this->getImages();

            return json_encode($arr);

        } else {

            return 'Erorr in operation';

        }
    }



    /**
     * @param $title_id
     * @return array|string
     */
    public function getExtractMediaImages($title_id)
    {

        if ($title_id !='') {

            return $this->getMediaImages($title_id);

        } else {

            return 'Erorr in operation';

        }
    }



    /**
     * @param $htmlContent
     * @return string|array
     */
    public function getExtractCast($htmlContent)
    {

        if ($htmlContent !='') {

            $regex = new Strings();
            $match_all = $regex->string()->regex->castAllKeyMatch;
            $match = $regex->string()->regex->castMatch;
            $matchStr = $this->match($match, $htmlContent, 1);
            $cast = $this->match_all_key_value($match_all, $matchStr);
            $cast = array_slice($cast, 0, 30);
            return $cast;
        } else {

            return 'Erorr in operation';

        }

    }


    /**
     * @param $htmlContent
     * @return mixed
     */
    public function getExtractTitle($htmlContent)
    {
        if ($htmlContent !='') {
            $regex = new Strings();
            $match = $regex->string()->regex->title;
            return str_replace('"', '', trim($this->match($match, $htmlContent, 2)));

        } else {

            return 'Erorr in operation';

        }
    }


    /**
     * @param $htmlContent
     * @return bool
     */
    public function getExtractTitleId($htmlContent)
    {

        if ($htmlContent !='') {

            $regex = new Strings();
            $match = $regex->string()->regex->titleId;
            return "" . $this->match($match, $htmlContent, 1);

        } else {

            return 'Erorr in operation';

        }

    }


    /**
     * @param $titleId
     * @return array|string
     */

    public function getMediaImages($titleId)
    {

        if ($titleId !='') {

            $regex = new Strings();
            $matchAll = $regex->string()->regex->mediaImagesMatchAll;
            $match = $regex->string()->regex->mediaImagesMatch;
            $urlSite = $regex->texts()->items->url;
            $url = $urlSite . $titleId . "/mediaindex";

            $htmlContent = $this->getContentOfUrl($url);
            $media = array();
            $media = array_merge($media, $this->scanMediaImages($htmlContent));
            $matchStr = $this->match($match, $htmlContent, 1);

            foreach ($this->match_all($matchAll, $matchStr, 1) as $p) {

                $htmlContent = $this->getContentOfUrl($url . "?page=" . $p);
                $media = array_merge($media, $this->scanMediaImages($htmlContent));

            }

            return $media;

        } else {

            return 'Erorr in operation';

        }
    }


    /**
     * @param $htmlContent
     * @return array|string
     */

    public function scanMediaImages($htmlContent)
    {

        if ($htmlContent !='') {

            $pics = array();
            $regex = new Strings();
            $matchAll = $regex->string()->regex->scanMediaMatchAll;
            $match = $regex->string()->regex->scanMediaMatch;

            $matchStr = $this->match($match, $htmlContent, 1);
            $regexPattern = '/_V1\..*?.jpg/ms';
            $Replacement = "_V1._SY0.jpg";
            foreach ($this->match_all($matchAll, $matchStr, 1) as $i) {

                array_push($pics, preg_replace($regexPattern, $Replacement, $i));

            }

            return array_filter($pics);

        } else {

            return 'Erorr in operation';

        }
    }



    /**
     * @param $regex
     * @param $str
     * @param int $keyIndex
     * @param int $valueIndex
     * @return array
     */
    private function match_all_key_value($regex, $str, $keyIndex = 1, $valueIndex = 2)
    {

        $arr = array();
        preg_match_all($regex, $str, $matches, PREG_SET_ORDER);
        foreach($matches as $m){
            $arr[$m[$keyIndex]] = $m[$valueIndex];
        }
        return $arr;
    }



    /**
     * @param $regex
     * @param $str
     * @param int $i
     * @return bool
     */
    private function match_all($regex, $str, $i = 0)
    {

        if (preg_match_all($regex, $str, $matches) === false)
            return false;
        else
            return $matches[$i];
    }



    /**
     * @param $regex
     * @param $str
     * @param int $i
     * @return bool
     */
    private function match($regex, $str, $i = 0)
    {

        if (preg_match($regex, $str, $match) == 1)
            return $match[$i];
        else
            return false;
    }



    /**
     * @param $url
     * @return mixed
     */
    private function getContentOfUrl($url)
    {

        if ($url !='') {

            $requestText = new Strings();
            $request = $requestText->texts()->items->request;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            $ip = rand(0, 255) . '.' . rand(0, 255) . '.' . rand(0, 255) . '.' . rand(0, 255);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array("REMOTE_ADDR: $ip", "HTTP_X_FORWARDED_FOR: $ip"));
            curl_setopt($ch, CURLOPT_USERAGENT,$request);
            $htmlContent = curl_exec($ch);
            curl_close($ch);

            return $htmlContent;

        } else {

            return 'Erorr in operation';

        }
    }


}