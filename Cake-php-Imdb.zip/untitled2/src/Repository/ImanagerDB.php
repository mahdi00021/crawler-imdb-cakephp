<?php

namespace App\Repository;


/**
 * @author mahdi norouzi
 * Interface ImanagerDB for pattern Repository
 * @package App\Repository
 */
interface ImanagerDB
{


    /**
     * @param $titleId
     * @param $title
     * @param $cast
     * @param $mediaImages
     * @return mixed
     */
    function insertData($titleId,$title,$cast,$mediaImages);

}