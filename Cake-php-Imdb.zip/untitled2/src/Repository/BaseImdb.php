<?php

namespace App\Repository;

use Cake\ORM\TableRegistry;

App::uses('ImanagerDB', 'Repository');


/**
 * @author mahdi norouzi
 * Class BaseImdb
 * @package App\Repository
 */
abstract class BaseImdb implements ImanagerDB
{

    /**
     * @param $titleId
     * @param $title
     * @param $cast
     * @param $mediaImages
     * @return string
     */
    function insertData($titleId,$title,$cast,$mediaImages)
    {

        if ($titleId && $title && $cast && $mediaImages !='') {

            $imdbItem = TableRegistry::get('Imdb');

            $query = $imdbItem->query();
            $query->insert(['titleId', 'title', 'cast', 'mediaImages'])
                ->values([
                    'titleId' => $titleId,
                    'title' => $title,
                    'cast' => $cast,
                    'mediaImages' => $mediaImages
                ])
                ->execute();

        } else {

            return 'Error in insert data';
        }


    }

}