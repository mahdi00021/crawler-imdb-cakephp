<?php


namespace App\Repository;


/**
 * @author mahdi norouzi
 * Class RepositoryImdb
 * @package App\Repository
 */
class RepositoryImdb extends BaseImdb implements ImanagerDB
{

    /**
    * @param  $titleId
    * @param  $title
    * @param  $cast
    * @param  $mediaImages
    * @return  string
    */

    public function insertData($titleId, $title, $cast, $mediaImages)
    {
        return parent::insertData($titleId, $title, $cast, $mediaImages);
    }


}